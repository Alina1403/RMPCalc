package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private EditText editTextTwo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText  = (EditText) findViewById(R.id.editText);
        editTextTwo = (EditText) findViewById(R.id.editTextTwo);

    }
public void clickButton (View view){
    int a,b,c;
    String s1 = editText.getText().toString();
    String s2 = editTextTwo.getText().toString();


     a = Integer.parseInt(s1);
     b = Integer.parseInt(s2);

     c = a + b;

    Intent intent = new Intent(this,SecondActivity.class);
    intent.putExtra("s1",editText.getText().toString());
    intent.putExtra("s2",editTextTwo.getText().toString());
    intent.putExtra("c",c);
    startActivity(intent);
}
}